﻿Console.Write("Birinci oyuncunun adı: ");
string oyuncu_bir = Console.ReadLine();
Console.Write("İkinci oyuncunun adı: ");
string oyuncu_iki = Console.ReadLine();
Console.WriteLine();

Oyuncu oyuncu1 = new(oyuncu_bir);
Oyuncu oyuncu2 = new(oyuncu_iki);

for (int i = 0; i < 3; i++) // oyun 3 tur oynanacak
{
    oyuncu1.ZarAt();
    oyuncu2.ZarAt();
}

if(oyuncu1.oyuncuPuani > oyuncu2.oyuncuPuani)
{
    Console.WriteLine("{0} isimli oyuncunun puanı: {1} \n{2} isimli oyuncunun puanı: {3} \n{0} isimli oyuncu kazandı!!! ", oyuncu1.oyuncuAdi, oyuncu1.oyuncuPuani, oyuncu2.oyuncuAdi, oyuncu2.oyuncuPuani);
} else if (oyuncu1.oyuncuPuani < oyuncu2.oyuncuPuani)
{
    Console.WriteLine("{0} isimli oyuncunun puanı: {1} \n{2} isimli oyuncunun puanı: {3} \n{2} isimli oyuncu kazandı!!! ", oyuncu1.oyuncuAdi, oyuncu1.oyuncuPuani, oyuncu2.oyuncuAdi, oyuncu2.oyuncuPuani);
} else
{
    Console.WriteLine("{0} isimli oyuncunun puanı: {1} \n{2} isimli oyuncunun puanı: {3} \nBERABERE! ", oyuncu1.oyuncuAdi, oyuncu1.oyuncuPuani, oyuncu2.oyuncuAdi, oyuncu2.oyuncuPuani);
}

class Zar
{

    int zarYuzu = 6;

    public int ZarAt(string oyuncuAdi)
    {
        Console.WriteLine("Zar atmak için bir tuşa bas.");
        Console.ReadKey();

        Random random = new Random();
        int zarinGelenYuzu = random.Next(1, zarYuzu);
        int zarinGelenDegeri = random.Next(1, 25);

        Console.WriteLine("Oyuncu {2} zar atıyor. Zarın {0}. yüzü geldi. Değeri: {1} \n", zarinGelenYuzu, zarinGelenDegeri, oyuncuAdi);

        return zarinGelenDegeri;
    }
}

public class Oyuncu
{   
    public Oyuncu(string isim) {
        oyuncuAdi = isim;
        oyuncuPuani = 0;
    }

    public string oyuncuAdi { get; private set; }
    public int oyuncuPuani { get; private set; }

    public void ZarAt()
    {
        Zar zar = new Zar();
        oyuncuPuani += zar.ZarAt(oyuncuAdi);
    }
}