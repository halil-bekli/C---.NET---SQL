﻿namespace Ödev5 {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            randevuSaatleri = new ComboBox();
            randevuSaatleriLabel = new Label();
            randevuOlusturmaButonu = new Button();
            kullanıcıAdıSoyadı = new TextBox();
            label1 = new Label();
            randevularıGosterBtn = new Button();
            SuspendLayout();
            // 
            // randevuSaatleri
            // 
            randevuSaatleri.FormattingEnabled = true;
            randevuSaatleri.Items.AddRange(new object[] { "08.30", "09.30", "10.30", "11.30", "13.30", "14.30", "15.30", "16.30" });
            randevuSaatleri.Location = new Point(320, 273);
            randevuSaatleri.Name = "randevuSaatleri";
            randevuSaatleri.Size = new Size(121, 23);
            randevuSaatleri.TabIndex = 0;
            // 
            // randevuSaatleriLabel
            // 
            randevuSaatleriLabel.AutoSize = true;
            randevuSaatleriLabel.BackColor = SystemColors.ControlDark;
            randevuSaatleriLabel.Location = new Point(335, 236);
            randevuSaatleriLabel.Name = "randevuSaatleriLabel";
            randevuSaatleriLabel.Size = new Size(94, 15);
            randevuSaatleriLabel.TabIndex = 1;
            randevuSaatleriLabel.Text = "Randevu Saatleri";
            // 
            // randevuOlusturmaButonu
            // 
            randevuOlusturmaButonu.Location = new Point(320, 354);
            randevuOlusturmaButonu.Name = "randevuOlusturmaButonu";
            randevuOlusturmaButonu.Size = new Size(121, 34);
            randevuOlusturmaButonu.TabIndex = 2;
            randevuOlusturmaButonu.Text = "Randevu Oluştur";
            randevuOlusturmaButonu.UseVisualStyleBackColor = true;
            randevuOlusturmaButonu.Click += randevuOlusturmaButonu_Click;
            // 
            // kullanıcıAdıSoyadı
            // 
            kullanıcıAdıSoyadı.Location = new Point(329, 161);
            kullanıcıAdıSoyadı.Name = "kullanıcıAdıSoyadı";
            kullanıcıAdıSoyadı.Size = new Size(100, 23);
            kullanıcıAdıSoyadı.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.AppWorkspace;
            label1.Location = new Point(346, 131);
            label1.Name = "label1";
            label1.Size = new Size(65, 15);
            label1.TabIndex = 4;
            label1.Text = "Ad - Soyad";
            // 
            // randevularıGosterBtn
            // 
            randevularıGosterBtn.BackColor = Color.FromArgb(0, 192, 192);
            randevularıGosterBtn.Location = new Point(627, 382);
            randevularıGosterBtn.Name = "randevularıGosterBtn";
            randevularıGosterBtn.Size = new Size(151, 56);
            randevularıGosterBtn.TabIndex = 5;
            randevularıGosterBtn.Text = "Randevuları Göster";
            randevularıGosterBtn.UseVisualStyleBackColor = false;
            randevularıGosterBtn.Click += randevularıGosterBtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(randevularıGosterBtn);
            Controls.Add(label1);
            Controls.Add(kullanıcıAdıSoyadı);
            Controls.Add(randevuOlusturmaButonu);
            Controls.Add(randevuSaatleriLabel);
            Controls.Add(randevuSaatleri);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox randevuSaatleri;
        private Label randevuSaatleriLabel;
        private Button randevuOlusturmaButonu;
        private TextBox kullanıcıAdıSoyadı;
        private Label label1;
        private Button randevularıGosterBtn;
    }
}
