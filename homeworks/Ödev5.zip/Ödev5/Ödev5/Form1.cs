using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Text;

namespace Ödev5 {
    public partial class Form1 : Form {

        /*
        List<string> randevuVerilenSaatler = new List<string>();
        List<string> randevuAlınabilirSaatler = new List<string>();
        */

        string dosyaYolu = "C:\\Randevu Bilgileri - Formlar - Ödev 5\\RandevuBilgileri.txt";

        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {/*
            for (int i = 0; i < randevuSaatleri.Items.Count; i++) {
                randevuAlınabilirSaatler.Add(Convert.ToString(randevuSaatleri.Items[i]));
            }*/
        }

        private void randevuOlusturmaButonu_Click(object sender, EventArgs e) {
            /*
            if(randevuAlınabilirSaatler.Contains(randevuSaatleri.SelectedItem)) {

            }
            */

            StreamReader streamReader = new StreamReader(dosyaYolu);

            string usttenEnYakinSaat = "";
            string alttanEnYakinSaat = "";
            bool randevuSaatiBosmu = true;


            while (streamReader.Peek() >= 0) {
                // dosyadaki tüm satırlara bakıyoruz

                string satir = streamReader.ReadLine();

                if (satir.Contains(randevuSaatleri.SelectedItem.ToString())) {
                    // eğer listeden seçilen saatte başka birisi randevu almışsa

                    for (int i = randevuSaatleri.SelectedIndex + 1; i < randevuSaatleri.Items.Count; i++) {
                        // yukarıdan en yakın randevu alınabilecek saati bulmak için sonraki itemlerin dosyada olup olmadığına bakıyorum
                        if (!satir.Contains(randevuSaatleri.Items[i].ToString())) {
                            // eger randevu listesindeki i nci item dosyada yoksa
                            usttenEnYakinSaat = randevuSaatleri.Items[i].ToString();
                            break;
                        }
                    }

                    for (int i = randevuSaatleri.SelectedIndex - 1; i >= 0; i--) {
                        // asagıdan en yakın randevu alınabilecek saati bulmak için sonraki itemlerin dosyada olup olmadığına bakıyorum
                        if (!satir.Contains(randevuSaatleri.Items[i].ToString())) {
                            // eger randevu listesindeki i nci item dosyada yoksa
                            alttanEnYakinSaat = randevuSaatleri.Items[i].ToString();
                            break;
                        }
                    }

                    MessageBox.Show($"Bu saatte randevu alamazsınız. Randevu alınabilecek en yakın saatler: {usttenEnYakinSaat} ve {alttanEnYakinSaat}");

                    randevuSaatiBosmu = false;

                    streamReader.Dispose();

                    break;
                } /*else {
                    // randevu ekleme
                    //streamReader.Dispose();

                    FileStream fs = new FileStream(dosyaYolu, FileMode.Append);

                    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8)) {
                        sw.WriteLine(kullanıcıAdıSoyadı.Text + " isimli kullanıcının saat " + randevuSaatleri.SelectedItem.ToString() + " de randevusu var.");
                    }

                    fs.Dispose();
                }*/
            }

            streamReader.Dispose();

            if(randevuSaatiBosmu == true) {
                    FileStream fs = new FileStream(dosyaYolu, FileMode.Append);

                    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8)) {
                        sw.WriteLine(kullanıcıAdıSoyadı.Text + " isimli kullanıcının saat " + randevuSaatleri.SelectedItem.ToString() + " de randevusu var.");
                    }

                    fs.Dispose();
            }
        }


        private void randevularıGosterBtn_Click(object sender, EventArgs e) {
            //FileStream fileStream = new FileStream(dosyaYolu, FileMode.Open);
            StreamReader streamReader = new StreamReader(dosyaYolu);

            List<string> randevuList = new List<string>();

            while (streamReader.Peek() >= 0) {
                randevuList.Add(streamReader.ReadLine() + "\n");
            }

            string randevular = null;

            foreach (var s in randevuList) {
                randevular += s.ToString();
            }

            MessageBox.Show(randevular);

            //fileStream.Dispose();
            streamReader.Dispose();
        }
    }
}