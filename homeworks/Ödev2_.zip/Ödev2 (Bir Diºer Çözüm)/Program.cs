﻿Oyuncu oyuncu1 = new Oyuncu();
Oyuncu oyuncu2 = new Oyuncu();

Console.WriteLine("Oyuncu 1 Adı: ");
oyuncu1.oyuncuAd = Console.ReadLine();
Console.WriteLine("Oyuncu 2 Adı: ");
oyuncu2.oyuncuAd = Console.ReadLine();

Console.WriteLine("Oyuncu 1: {0}", oyuncu1.oyuncuAd);
Console.WriteLine("Oyuncu 2: {0}", oyuncu2.oyuncuAd);

int i = 0;

do
{
    oyuncu1.ZarAt(oyuncu1);
    oyuncu2.ZarAt(oyuncu2);
    i++;
} while (i < 2);

if (oyuncu1.oyuncuPuan > oyuncu2.oyuncuPuan)
{
    Console.WriteLine("Oyuncu1 {0} kazandı, tebrikler!! ", oyuncu1.oyuncuAd);
}
else if (oyuncu1.oyuncuPuan == oyuncu2.oyuncuPuan)
{
    Console.WriteLine("Puanlarınız eşit.");
}
else
{
    Console.WriteLine("Oyuncu2 {0} kazandı.", oyuncu2.oyuncuAd);
}

Console.WriteLine("Oyuncu 1 Toplam Puanı: {0} \nOyuncu 2 Toplam Puanı: {1}", oyuncu1.oyuncuPuan, oyuncu2.oyuncuPuan);

class Zar
{
    int zarYuzu = 6;
    int zarDegeri = 25;

    public void ZarAt(Oyuncu oyuncu, string oyuncuAdi)
    {
        Random random = new Random();

        int zarinGelenYuzu = random.Next(1, zarYuzu);

        int zarinGelenDegeri = random.Next(1, zarDegeri);

        Console.WriteLine("Zar atmak için enter a bas");
        Console.ReadKey();

        Console.WriteLine("Oyuncu {0} zarı attı. Zarın {1}. yüzü geldi. Değeri {2}. ", oyuncuAdi, zarinGelenYuzu, zarinGelenDegeri);

        Console.WriteLine("Gelen puanı gir: ");
        oyuncu.oyuncuPuan = oyuncu.oyuncuPuan + Convert.ToInt32(Console.ReadLine());
    }

}

class Oyuncu
{
    public string oyuncuAd;

    public int oyuncuPuan;

    public void ZarAt(Oyuncu oyuncu)
    {
        Zar zar = new Zar();

        zar.ZarAt(oyuncu, oyuncuAd);
    }
}