/*
for (int i = 0; i < player.oyuncuDestesi.Count; i++) {
    for (int j = 0; j < ortadakiKartlar.Count; j++) {
        string ortadakiKartlardan_i_nci = ortadakiKartlar[j];
        string oyuncununElindekiKartlardan_j_nci = player.oyuncuDestesi[i];

        bool bireBirCalismadi = true;

        // oyuncunun kartlar�n� ve ortadaki kartlar� tek tek kar��la�t�r�yoruz
        if (player.oyuncuDestesi[i].Contains("Re") && ortadakiKartlardan_i_nci.Contains("Re")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("Cavallo") && ortadakiKartlardan_i_nci.Contains("Cavallo")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("Fante") && ortadakiKartlardan_i_nci.Contains("Fante")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("7") && ortadakiKartlardan_i_nci.Contains("7")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("6") && ortadakiKartlardan_i_nci.Contains("6")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("5") && ortadakiKartlardan_i_nci.Contains("5")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("4") && ortadakiKartlardan_i_nci.Contains("4")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("3") && ortadakiKartlardan_i_nci.Contains("3")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("2") && ortadakiKartlardan_i_nci.Contains("2")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        } else if (player.oyuncuDestesi[i].Contains("1") && ortadakiKartlardan_i_nci.Contains("1")) {
            player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_i_nci);
            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_j_nci);
            ortadakiKartlar.Remove(ortadakiKartlardan_i_nci);
            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_j_nci);
            bireBirCalismadi = false;
        }

        // Toplam �eklinde yap�lan kar��la�t�rmalar

        if (bireBirCalismadi) {
            if (oyuncununElindekiKartlardan_j_nci.Contains("2")) {
                //if (ortadakiKartlar[k].Contains("1") && ortadakiKartlar[k + 1].Contains("1"));
                List<string> geciciListe = new List<string>();
                foreach (string s in ortadakiKartlar) {
                    if (s.Contains("1"))
                        geciciListe.Add(s);
                }
                if (geciciListe.Count == 2) {
                    player.oyuncuKoleksiyonu.AddRange(geciciListe);

                    for (int a = 0; a < geciciListe.Count; a++) {
                        ortadakiKartlar.Remove(geciciListe[a]);
                    }
                } else if (geciciListe.Count >= 2) { // eger ikiden fazla (3) say�da "1" say�s� i�eren kart varsa
                    for (int a = 0; a < geciciListe.Count; a++) {
                        Random random = new Random();

                        string kart1 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                        player.oyuncuKoleksiyonu.Add(kart1);
                        ortadakiKartlar.Remove(kart1);
                        // 3 kart aras�ndan rastgele iki kart� al�p oyuncu koleksiyonuna ekliyoruz
                        string kart2 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                        player.oyuncuKoleksiyonu.Add(kart2);
                        ortadakiKartlar.Remove(kart2);
                    }
                }

            } else if (oyuncununElindekiKartlardan_j_nci.Contains("3")) {
                List<string> geciciListe = new List<string>();
                foreach (string s in ortadakiKartlar) {
                    if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 2) {
                        geciciListe.Add(s);
                    }
                }

                for (int a = 0; a < geciciListe.Count; a++) {
                    for (int b = 0; b < geciciListe.Count; b++) {
                        if (a == b) {
                            return;
                        }
                        if (Convert.ToInt32(geciciListe[a]) + Convert.ToInt32(geciciListe[b]) == 3) {
                            player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                            player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                            ortadakiKartlar.Remove(geciciListe[a]);
                            ortadakiKartlar.Remove(geciciListe[b]);
                        }
                    }
                }

            } else if (oyuncununElindekiKartlardan_j_nci.Contains("4")) {

                List<string> geciciListe = new List<string>();
                foreach (string s in ortadakiKartlar) {
                    if (s.Contains("2"))
                        geciciListe.Add(s);
                }

                if (geciciListe.Count == 2) {
                    player.oyuncuKoleksiyonu.AddRange(geciciListe);

                    for (int a = 0; a < geciciListe.Count; a++) {
                        ortadakiKartlar.Remove(geciciListe[a]);
                    }
                } else if (geciciListe.Count >= 2) { // eger ikiden fazla (3) say�da "2" say�s� i�eren kart varsa
                    for (int a = 0; a < geciciListe.Count; a++) {
                        Random random = new Random();

                        string kart1 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                        player.oyuncuKoleksiyonu.Add(kart1);
                        ortadakiKartlar.Remove(kart1);
                        // 3 kart aras�ndan rastgele iki kart� al�p oyuncu koleksiyonuna ekliyoruz
                        string kart2 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                        player.oyuncuKoleksiyonu.Add(kart2);
                        ortadakiKartlar.Remove(kart2);
                    }
                } else { // eger yeterince 2 yoksa
                    List<string> geciciListe2 = new List<string>();
                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 3) {
                            geciciListe2.Add(s);
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);
                                    }
                                }
                            }
                        }
                    }
                }

            } else if (oyuncununElindekiKartlardan_j_nci.Contains("5")) {
                bool calismadi = true;

                List<string> geciciListe = new List<string>();

                foreach (string s in ortadakiKartlar) {
                    if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 4) {
                        geciciListe.Add(s);
                    }
                }
                for (int a = 0; a < geciciListe.Count; a++) {
                    for (int b = 0; b < geciciListe.Count; b++) {
                        if (a == b) {
                            return;
                        }
                        if (Convert.ToInt32(geciciListe[a]) + Convert.ToInt32(geciciListe[b]) == 4) {
                            player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                            player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                            ortadakiKartlar.Remove(geciciListe[a]);
                            ortadakiKartlar.Remove(geciciListe[b]);
                            calismadi = false;
                        }
                    }
                }

                if (calismadi) {
                    List<string> geciciListe2 = new List<string>();
                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 3) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                            }
                        }
                    }
                }
            } else if (oyuncununElindekiKartlardan_j_nci.Contains("6")) {
                bool calismadi = true;

                List<string> geciciListe = new List<string>();

                foreach (string s in ortadakiKartlar) {
                    if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                        geciciListe.Add(s);
                    }
                }
                for (int a = 0; a < geciciListe.Count; a++) {
                    for (int b = 0; b < geciciListe.Count; b++) {
                        if (a == b) {
                            return;
                        }
                        if (Convert.ToInt32(geciciListe[a]) + Convert.ToInt32(geciciListe[b]) == 4) {
                            player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                            player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                            ortadakiKartlar.Remove(geciciListe[a]);
                            ortadakiKartlar.Remove(geciciListe[b]);
                            calismadi = false;
                        }
                    }
                }

                bool calismadi2 = true;

                if (calismadi) {
                    List<string> geciciListe2 = new List<string>();
                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 4) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi2 = false;
                            }
                        }
                    }
                }

                if (calismadi2) {
                    List<string> geciciListe2 = new List<string>();
                    foreach (string s in ortadakiKartlar) {
                        if (s.Contains("3"))
                            geciciListe2.Add(s);
                    }

                    if (geciciListe2.Count == 2) {
                        player.oyuncuKoleksiyonu.AddRange(geciciListe2);

                        for (int a = 0; a < geciciListe2.Count; a++) {
                            ortadakiKartlar.Remove(geciciListe2[a]);
                        }
                    } else if (geciciListe2.Count >= 2) { // eger ikiden fazla (3) say�da "2" say�s� i�eren kart varsa
                        for (int a = 0; a < geciciListe2.Count; a++) {
                            Random random = new Random();

                            string kart1 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                            player.oyuncuKoleksiyonu.Add(kart1);
                            ortadakiKartlar.Remove(kart1);
                            // 3 kart aras�ndan rastgele iki kart� al�p oyuncu koleksiyonuna ekliyoruz
                            string kart2 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                            player.oyuncuKoleksiyonu.Add(kart2);
                            ortadakiKartlar.Remove(kart2);
                        }
                    }
                }
            } else if (oyuncununElindekiKartlardan_j_nci.Contains("7")) {
                bool calismadi = true;

                List<string> geciciListe = new List<string>();

                foreach (string s in ortadakiKartlar) {
                    if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                        geciciListe.Add(s);
                    }
                }
                for (int a = 0; a < geciciListe.Count; a++) {
                    for (int b = 0; b < geciciListe.Count; b++) {
                        if (a == b) {
                            return;
                        }
                        if (Convert.ToInt32(geciciListe[a]) + Convert.ToInt32(geciciListe[b]) == 4) {
                            player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                            player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                            ortadakiKartlar.Remove(geciciListe[a]);
                            ortadakiKartlar.Remove(geciciListe[b]);
                            calismadi = false;
                        }
                    }
                }

                bool calismadi2 = true;

                if (calismadi) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi2 = false;
                            }
                        }
                    }
                }

                if (calismadi2) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 4) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi2 = false;
                            }
                        }
                    }
                }
            } else if (oyuncununElindekiKartlardan_j_nci.Contains("Fante")) {
                bool calismadi = true;

                List<string> geciciListe = new List<string>();

                foreach (string s in ortadakiKartlar) {
                    if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 7) {
                        geciciListe.Add(s);
                    }
                }
                for (int a = 0; a < geciciListe.Count; a++) {
                    for (int b = 0; b < geciciListe.Count; b++) {
                        if (a == b) {
                            return;
                        }
                        if (Convert.ToInt32(geciciListe[a]) + Convert.ToInt32(geciciListe[b]) == 4) {
                            player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                            player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                            ortadakiKartlar.Remove(geciciListe[a]);
                            ortadakiKartlar.Remove(geciciListe[b]);
                            calismadi = false;
                        }
                    }
                }

                bool calismadi2 = true;

                if (calismadi) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi2 = false;
                            }
                        }
                    }
                }

                bool calismadi3 = true;

                if (calismadi2) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi3 = false;
                            }
                        }
                    }
                }

                if (calismadi3) {
                    List<string> geciciListe2 = new List<string>();
                    foreach (string s in ortadakiKartlar) {
                        if (s.Contains("4"))
                            geciciListe2.Add(s);
                    }

                    if (geciciListe2.Count == 2) {
                        player.oyuncuKoleksiyonu.AddRange(geciciListe2);

                        for (int a = 0; a < geciciListe2.Count; a++) {
                            ortadakiKartlar.Remove(geciciListe2[a]);
                        }
                    } else if (geciciListe2.Count >= 2) { // eger ikiden fazla (3) say�da "4" say�s� i�eren kart varsa
                        for (int a = 0; a < geciciListe2.Count; a++) {
                            Random random = new Random();

                            string kart1 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                            player.oyuncuKoleksiyonu.Add(kart1);
                            ortadakiKartlar.Remove(kart1);
                            // 3 kart aras�ndan rastgele iki kart� al�p oyuncu koleksiyonuna ekliyoruz
                            string kart2 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                            player.oyuncuKoleksiyonu.Add(kart2);
                            ortadakiKartlar.Remove(kart2);
                        }
                    }
                }
            } else if (oyuncununElindekiKartlardan_j_nci.Contains("Cavallo")) {
                bool calismadi = true;

                List<string> geciciListe = new List<string>();

                foreach (string s in ortadakiKartlar) {
                    if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 8) {
                        geciciListe.Add(s);
                    }
                }
                for (int a = 0; a < geciciListe.Count; a++) {
                    for (int b = 0; b < geciciListe.Count; b++) {
                        if (a == b) {
                            return;
                        }
                        if (Convert.ToInt32(geciciListe[a]) + Convert.ToInt32(geciciListe[b]) == 4) {
                            player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                            player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                            ortadakiKartlar.Remove(geciciListe[a]);
                            ortadakiKartlar.Remove(geciciListe[b]);
                            calismadi = false;
                        }
                    }
                }

                bool calismadi2 = true;

                if (calismadi) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 7) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi2 = false;
                            }
                        }
                    }
                }

                bool calismadi3 = true;

                if (calismadi2) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi3 = false;
                            }
                        }
                    }
                }

                if (calismadi3) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 4 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                            }
                        }
                    }
                }
            } else if (oyuncununElindekiKartlardan_j_nci.Contains("Re")) {
                bool calismadi = true;

                List<string> geciciListe = new List<string>();

                foreach (string s in ortadakiKartlar) {
                    if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 9) {
                        geciciListe.Add(s);
                    }
                }
                for (int a = 0; a < geciciListe.Count; a++) {
                    for (int b = 0; b < geciciListe.Count; b++) {
                        if (a == b) {
                            return;
                        }
                        if (Convert.ToInt32(geciciListe[a]) + Convert.ToInt32(geciciListe[b]) == 4) {
                            player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                            player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                            ortadakiKartlar.Remove(geciciListe[a]);
                            ortadakiKartlar.Remove(geciciListe[b]);
                            calismadi = false;
                        }
                    }
                }

                bool calismadi2 = true;

                if (calismadi) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 8) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi2 = false;
                            }
                        }
                    }
                }

                bool calismadi3 = true;

                if (calismadi2) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 7) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi3 = false;
                            }
                        }
                    }
                }

                bool calismadi4 = true;

                if (calismadi3) {
                    List<string> geciciListe2 = new List<string>();

                    foreach (string s in ortadakiKartlar) {
                        if (Convert.ToInt32(s.Substring(0, 1)) == 4 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                            geciciListe2.Add(s);
                        }
                    }
                    for (int a = 0; a < geciciListe2.Count; a++) {
                        for (int b = 0; b < geciciListe2.Count; b++) {
                            if (a == b) {
                                return;
                            }
                            if (Convert.ToInt32(geciciListe2[a]) + Convert.ToInt32(geciciListe2[b]) == 4) {
                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                ortadakiKartlar.Remove(geciciListe2[a]);
                                ortadakiKartlar.Remove(geciciListe2[b]);
                                calismadi3 = false;
                            }
                        }
                    }
                }

                if (calismadi4) {
                    List<string> geciciListe2 = new List<string>();
                    foreach (string s in ortadakiKartlar) {
                        if (s.Contains("5"))
                            geciciListe2.Add(s);
                    }

                    if (geciciListe2.Count == 2) {
                        player.oyuncuKoleksiyonu.AddRange(geciciListe2);

                        for (int a = 0; a < geciciListe2.Count; a++) {
                            ortadakiKartlar.Remove(geciciListe2[a]);
                        }
                    } else if (geciciListe2.Count >= 2) { // eger ikiden fazla (3) say�da "4" say�s� i�eren kart varsa
                        for (int a = 0; a < geciciListe2.Count; a++) {
                            Random random = new Random();

                            string kart1 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                            player.oyuncuKoleksiyonu.Add(kart1);
                            ortadakiKartlar.Remove(kart1);
                            // 3 kart aras�ndan rastgele iki kart� al�p oyuncu koleksiyonuna ekliyoruz
                            string kart2 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                            player.oyuncuKoleksiyonu.Add(kart2);
                            ortadakiKartlar.Remove(kart2);
                        }
                    }
                }
            }
        }

        if (ortadakiKartlar.Count == 1) {
            if (oyuncununElindekiKartlardan_j_nci == ortadakiKartlar[0]) {
                player.scopaSayisi += 1;
            }
        }
    }
}

*/