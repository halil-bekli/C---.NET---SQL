﻿Player player1 = new Player();
Player player2 = new Player();

int dogumGunu;

Console.WriteLine("             - Scopa -           \n");

Console.WriteLine("Birinci oyuncu adını giriniz: ");
player1.oyuncuAdi = Console.ReadLine();

Console.WriteLine("İkinci oyuncu adını giriniz: ");
player2.oyuncuAdi = Console.ReadLine();

Console.WriteLine("Bir doğum günü giriniz: ");
dogumGunu = Convert.ToInt32(Console.ReadLine());

Scopa scopa = new Scopa(dogumGunu);

Player gecici = new Player(); // tur sonunda oynama sırasını degistirmek icin
Player gecici2 = new Player();

gecici = player1;
gecici2 = player2;

while ((player1.oyuncuPuani != 11 || player1.oyuncuPuani < 11) || (player2.oyuncuPuani != 11 || player2.oyuncuPuani! < 11)) {

    scopa.OyunuVeyaTuruBaslat(player1, player2); // sadece her turun başında

    for (int i = 0; i < 6; i++) {
        /*if (i == 0)
            return; // !!! debuger a göre buradan birkaç satır önce program kırılıyor !!!
        else { 
            scopa.KartDagıt(player1, player2); 
        } */
        scopa.KartDagıt(player1, player2);

        for (int j = 0; j < 3; j++) {
            scopa.OyunuBirElOynat(player1);
            if (i == 5 && j == 2) { // turdaki en son el
                scopa.SonEl(player1 , player2);
                break;
            }
            scopa.OyunuBirElOynat(player2);
        }
    }

    /*
    player1 = player2; // tur sonunda oynama sırasını degistiriyorlar
    player2 = gecici;
    */

    scopa.PuanHesapla(player1, player2); // Tur sonu puan hesaplama

    /*
    if (player1.oyuncuDestesi == null && player2.oyuncuDestesi == null) {
        scopa.KartDagıt(player1, player2);
    }
    if (scopa.ortadakiKartlar == null) {
        scopa.OrtayaKartKoy();
    }
    */
}
//scopa.oyunDestesi.Clear();

/*
player1 = gecici;
player2 = gecici2;
*/

scopa.OyuncuKartlarınıGöster(player1);
scopa.OyuncuKartlarınıGöster(player2);

scopa.OyunuKazananOyuncuyuGoster(player1, player2);
Console.ReadKey();

public class Scopa {
    List<string> scopaDestesi = new List<string>(40) {
        "1 Altın", "2 Altın", "3 Altın", "4 Altın", "5 Altın", "6 Altın", "7 Altın", "8 AltınFante", "9 AltınCavallo", "10 AltınRe",
        "1 Kupa", "2 Kupa", "3 Kupa", "4 Kupa", "5 Kupa", "6 Kupa", "7 Kupa", "8 KupaFante", "9 KupaCavallo", "10 KupaRe",
        "1 Kılıç", "2 Kılıç", "3 Kılıç", "4 Kılıç", "5 Kılıç", "6 Kılıç", "7 Kılıç", "8 KılıçFante", "9 KılıçCavallo", "10 KılıçRe",
        "1 Sopa", "2 Sopa", "3 Sopa", "4 Sopa", "5 Sopa", "6 Sopa", "7 Sopa", "8 SopaFante", "9 SopaCavallo", "10 SopaRe"
    };

    public List<string> oyunDestesi = new List<string>();
    public List<string> ortadakiKartlar = new List<string>();

    int dogumGunu;

    public Scopa(int dogumGunu) {
        this.dogumGunu = dogumGunu;
    }

    public void KartlarıKar(Player player1, Player player2) {
        KartlarıTopla(player1, player2); // Scopa Destesini kopyaladim
        
        Random random = new Random();

        for (int i = 0; i < dogumGunu; i++) {
            string kart = oyunDestesi[random.Next(0, oyunDestesi.Count - 1)];
            oyunDestesi.Remove(kart);
            oyunDestesi.Insert(random.Next(0, oyunDestesi.Count - 1), kart);
        }
    }

    public void KartDagıt(Player player1, Player player2) {

        Random random = new Random();

        
            for (int i = 0; i < 3; i++) {
                string kart_ = oyunDestesi[random.Next(0, oyunDestesi.Count - 1)]; // oyuncuların kartlarını dagıtıyoruz
                player1.oyuncuDestesi.Add(kart_);
                oyunDestesi.Remove(kart_);

                string kart__ = oyunDestesi[random.Next(0, oyunDestesi.Count - 1)];
                player2.oyuncuDestesi.Add(kart__);
                oyunDestesi.Remove(kart__);
            }
        
    }

    public void OrtayaKartKoy() {

        Random random = new Random();

        
            for (int i = 0; i < 4; i++) {
                string kart = oyunDestesi[random.Next(0, oyunDestesi.Count - 1)]; // kartları ortaya koyuyoruz
                ortadakiKartlar.Add(kart);
                oyunDestesi.Remove(kart);
           }
        
    }

    public void KartlarıTopla(Player player1, Player player2) {
        if (oyunDestesi.Count == 0)
        oyunDestesi.AddRange(scopaDestesi);

        ortadakiKartlar.Clear();
        player1.oyuncuDestesi.Clear();
        player1.oyuncuKoleksiyonu.Clear();
        player2.oyuncuDestesi.Clear();
        player2.oyuncuKoleksiyonu.Clear();
    }

    public void OyunuVeyaTuruBaslat(Player player1, Player player2) {
        KartlarıKar(player1, player2);
        OrtayaKartKoy();
    }

    public void OyunuBirElOynat(Player player) {
        /*if (player1.oyuncuDestesi == null && player2.oyuncuDestesi == null) {
            SonEl();
            return;
        }*/

        int elinBasindaOrtadakiKartSayisi = ortadakiKartlar.Count;

        int oyuncununDestesindekiKartSayisi = player.oyuncuDestesi.Count;
        int ortadakiKartSayisi = ortadakiKartlar.Count;

        for (int i = oyuncununDestesindekiKartSayisi - 1; i >= 0; i--) {
            for (int j = ortadakiKartSayisi - 1; j >= 0; j--) {
                
                string ortadakiKartlardan_j_nci = ortadakiKartlar[j];
                string oyuncununElindekiKartlardan_i_nci = player.oyuncuDestesi[i];

                bool bireBirCalismadi = true;

                if (ortadakiKartlar.Count == 1) {
                    if (oyuncununElindekiKartlardan_i_nci == ortadakiKartlar[0]) {
                        player.scopaSayisi += 1;
                    }
                }

                // oyuncunun kartlarını ve ortadaki kartları tek tek karşılaştırıyoruz
                if (player.oyuncuDestesi[i-1].Contains("Re") && ortadakiKartlardan_j_nci.Contains("Re")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("Cavallo") && ortadakiKartlardan_j_nci.Contains("Cavallo")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("Fante") && ortadakiKartlardan_j_nci.Contains("Fante")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("7") && ortadakiKartlardan_j_nci.Contains("7")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("6") && ortadakiKartlardan_j_nci.Contains("6")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("5") && ortadakiKartlardan_j_nci.Contains("5")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("4") && ortadakiKartlardan_j_nci.Contains("4")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("3") && ortadakiKartlardan_j_nci.Contains("3")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("2") && ortadakiKartlardan_j_nci.Contains("2")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                } else if (player.oyuncuDestesi[i - 1].Contains("1") && ortadakiKartlardan_j_nci.Contains("1")) {
                    player.oyuncuKoleksiyonu.Add(ortadakiKartlardan_j_nci);
                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                    ortadakiKartlar.Remove(ortadakiKartlardan_j_nci);
                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                    bireBirCalismadi = false;
                }

                // Toplam şeklinde yapılan karşılaştırmalar

                if (bireBirCalismadi) {
                    if (oyuncununElindekiKartlardan_i_nci.Contains("2")) {
                        //if (ortadakiKartlar[k].Contains("1") && ortadakiKartlar[k + 1].Contains("1"));
                        List<string> geciciListe = new List<string>();
                        foreach (string s in ortadakiKartlar) {
                            if (s.Contains("1"))
                                geciciListe.Add(s);
                        }
                        if (geciciListe.Count == 2) {
                            player.oyuncuKoleksiyonu.AddRange(geciciListe);

                            for (int a = 0; a < geciciListe.Count; a++) {
                                ortadakiKartlar.Remove(geciciListe[a]);
                            }

                            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                        } else if (geciciListe.Count >= 2) { // eger ikiden fazla (3) sayıda "1" sayısı içeren kart varsa
                            
                                Random random = new Random();

                                string kart1 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                                player.oyuncuKoleksiyonu.Add(kart1);
                                ortadakiKartlar.Remove(kart1);
                                // 3 kart arasından rastgele iki kartı alıp oyuncu koleksiyonuna ekliyoruz
                                string kart2 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                                player.oyuncuKoleksiyonu.Add(kart2);
                                ortadakiKartlar.Remove(kart2);
                            

                            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                        }

                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("3")) {
                        List<string> geciciListe = new List<string>();
                        foreach (string s in ortadakiKartlar) {
                            if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 2) {
                                geciciListe.Add(s);
                            }
                        }

                        for (int a = 0; a < geciciListe.Count; a++) {
                            for (int b = 0; b < geciciListe.Count; b++) {
                                if (a == b) {
                                    return;
                                }
                                if (Convert.ToInt32(geciciListe[a].Substring(0,1)) + Convert.ToInt32(geciciListe[b].Substring(0, 1)) == 3) {
                                    player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                                    player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                                    ortadakiKartlar.Remove(geciciListe[a]);
                                    ortadakiKartlar.Remove(geciciListe[b]);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                                }
                            }
                        }

                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("4")) {

                        List<string> geciciListe = new List<string>();
                        foreach (string s in ortadakiKartlar) {
                            if (s.Contains("2"))
                                geciciListe.Add(s);
                        }

                        if (geciciListe.Count == 2) {
                            player.oyuncuKoleksiyonu.AddRange(geciciListe);

                            for (int a = 0; a < geciciListe.Count; a++) {
                                ortadakiKartlar.Remove(geciciListe[a]);
                            }

                            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                        } else if (geciciListe.Count >= 2) { // eger ikiden fazla (3) sayıda "2" sayısı içeren kart varsa
                            
                                Random random = new Random();

                                string kart1 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                                player.oyuncuKoleksiyonu.Add(kart1);
                                ortadakiKartlar.Remove(kart1);
                                // 3 kart arasından rastgele iki kartı alıp oyuncu koleksiyonuna ekliyoruz
                                string kart2 = geciciListe[random.Next(0, geciciListe.Count - 1)];
                                player.oyuncuKoleksiyonu.Add(kart2);
                                ortadakiKartlar.Remove(kart2);
                            

                            player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                            player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                        } else { // eger yeterince 2 yoksa
                            List<string> geciciListe2 = new List<string>();
                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 3) {
                                    geciciListe2.Add(s);
                                    for (int a = 0; a < geciciListe2.Count; a++) {
                                        for (int b = 0; b < geciciListe2.Count; b++) {
                                            if (a == b) {
                                                return;
                                            }
                                            if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 4) {
                                                player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                                player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                                ortadakiKartlar.Remove(geciciListe2[a]);
                                                ortadakiKartlar.Remove(geciciListe2[b]);

                                                player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                                player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("5")) {
                        bool calismadi = true;

                        List<string> geciciListe = new List<string>();

                        foreach (string s in ortadakiKartlar) {
                            if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 4) {
                                geciciListe.Add(s);
                            }
                        }
                        for (int a = 0; a < geciciListe.Count; a++) {
                            for (int b = 0; b < geciciListe.Count; b++) {
                                if (a == b) {
                                    return;
                                }
                                if (Convert.ToInt32(geciciListe[a].Substring(0, 1)) + Convert.ToInt32(geciciListe[b].Substring(0, 1)) == 5) {
                                    player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                                    player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                                    ortadakiKartlar.Remove(geciciListe[a]);
                                    ortadakiKartlar.Remove(geciciListe[b]);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                    calismadi = false;
                                }
                            }
                        }

                        if (calismadi) {
                            List<string> geciciListe2 = new List<string>();
                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 3) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 5) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                                    }
                                }
                            }
                        }
                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("6")) {
                        bool calismadi = true;

                        List<string> geciciListe = new List<string>();

                        foreach (string s in ortadakiKartlar) {
                            if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                                geciciListe.Add(s);
                            }
                        }
                        for (int a = 0; a < geciciListe.Count; a++) {
                            for (int b = 0; b < geciciListe.Count; b++) {
                                if (a == b) {
                                    return;
                                }
                                if (Convert.ToInt32(geciciListe[a].Substring(0, 1)) + Convert.ToInt32(geciciListe[b].Substring(0, 1)) == 6) {
                                    player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                                    player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                                    ortadakiKartlar.Remove(geciciListe[a]);
                                    ortadakiKartlar.Remove(geciciListe[b]);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                    calismadi = false;
                                }
                            }
                        }

                        bool calismadi2 = true;

                        if (calismadi) {
                            List<string> geciciListe2 = new List<string>();
                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 4) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 6) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi2 = false;
                                    }
                                }
                            }
                        }

                        if (calismadi2) {
                            List<string> geciciListe2 = new List<string>();
                            foreach (string s in ortadakiKartlar) {
                                if (s.Contains("3"))
                                    geciciListe2.Add(s);
                            }

                            if (geciciListe2.Count == 2) {
                                player.oyuncuKoleksiyonu.AddRange(geciciListe2);

                                player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                for (int a = 0; a < geciciListe2.Count; a++) {
                                    ortadakiKartlar.Remove(geciciListe2[a]);
                                }
                            } else if (geciciListe2.Count >= 2) { // eger ikiden fazla (3) sayıda "2" sayısı içeren kart varsa
                                
                                    Random random = new Random();

                                    string kart1 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                                    player.oyuncuKoleksiyonu.Add(kart1);
                                    ortadakiKartlar.Remove(kart1);
                                    // 3 kart arasından rastgele iki kartı alıp oyuncu koleksiyonuna ekliyoruz
                                    string kart2 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                                    player.oyuncuKoleksiyonu.Add(kart2);
                                    ortadakiKartlar.Remove(kart2);
                                

                                player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                            }
                        }
                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("7")) {
                        bool calismadi = true;

                        List<string> geciciListe = new List<string>();

                        foreach (string s in ortadakiKartlar) {
                            if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                                geciciListe.Add(s);
                            }
                        }
                        for (int a = 0; a < geciciListe.Count; a++) {
                            for (int b = 0; b < geciciListe.Count; b++) {
                                if (a == b) {
                                    return;
                                }
                                if (Convert.ToInt32(geciciListe[a].Substring(0, 1)) + Convert.ToInt32(geciciListe[b].Substring(0, 1)) == 7) {
                                    player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                                    player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                                    ortadakiKartlar.Remove(geciciListe[a]);
                                    ortadakiKartlar.Remove(geciciListe[b]);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                    calismadi = false;
                                }
                            }
                        }

                        bool calismadi2 = true;

                        if (calismadi) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 7) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi2 = false;
                                    }
                                }
                            }
                        }

                        if (calismadi2) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 4) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 7) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi2 = false;
                                    }
                                }
                            }
                        }
                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("Fante")) {
                        bool calismadi = true;

                        List<string> geciciListe = new List<string>();

                        foreach (string s in ortadakiKartlar) {
                            if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 7) {
                                geciciListe.Add(s);
                            }
                        }
                        for (int a = 0; a < geciciListe.Count; a++) {
                            for (int b = 0; b < geciciListe.Count; b++) {
                                if (a == b) {
                                    return;
                                }
                                if (Convert.ToInt32(geciciListe[a].Substring(0, 1)) + Convert.ToInt32(geciciListe[b].Substring(0, 1)) == 8) {
                                    player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                                    player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                                    ortadakiKartlar.Remove(geciciListe[a]);
                                    ortadakiKartlar.Remove(geciciListe[b]);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                    calismadi = false;
                                }
                            }
                        }

                        bool calismadi2 = true;

                        if (calismadi) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 8) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi2 = false;
                                    }
                                }
                            }
                        }

                        bool calismadi3 = true;

                        if (calismadi2) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 8) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi3 = false;
                                    }
                                }
                            }
                        }

                        if (calismadi3) {
                            List<string> geciciListe2 = new List<string>();
                            foreach (string s in ortadakiKartlar) {
                                if (s.Contains("4"))
                                    geciciListe2.Add(s);
                            }

                            if (geciciListe2.Count == 2) {
                                player.oyuncuKoleksiyonu.AddRange(geciciListe2);

                                player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                for (int a = 0; a < geciciListe2.Count; a++) {
                                    ortadakiKartlar.Remove(geciciListe2[a]);
                                }
                            } else if (geciciListe2.Count >= 2) { // eger ikiden fazla (3) sayıda "4" sayısı içeren kart varsa
                                    Random random = new Random();

                                    string kart1 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                                    player.oyuncuKoleksiyonu.Add(kart1);
                                    ortadakiKartlar.Remove(kart1);
                                    // 3 kart arasından rastgele iki kartı alıp oyuncu koleksiyonuna ekliyoruz
                                    string kart2 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                                    player.oyuncuKoleksiyonu.Add(kart2);
                                    ortadakiKartlar.Remove(kart2);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                                
                            }
                        }
                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("Cavallo")) {
                        bool calismadi = true;

                        List<string> geciciListe = new List<string>();

                        foreach (string s in ortadakiKartlar) {
                            if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 8) {
                                geciciListe.Add(s);
                            }
                        }
                        for (int a = 0; a < geciciListe.Count; a++) {
                            for (int b = 0; b < geciciListe.Count; b++) {
                                if (a == b) {
                                    return;
                                }
                                if (Convert.ToInt32(geciciListe[a].Substring(0, 1)) + Convert.ToInt32(geciciListe[b].Substring(0, 1)) == 9) {
                                    player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                                    player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                                    ortadakiKartlar.Remove(geciciListe[a]);
                                    ortadakiKartlar.Remove(geciciListe[b]);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                    calismadi = false;
                                }
                            }
                        }

                        bool calismadi2 = true;

                        if (calismadi) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 7) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 9) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi2 = false;
                                    }
                                }
                            }
                        }

                        bool calismadi3 = true;

                        if (calismadi2) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 9) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi3 = false;
                                    }
                                }
                            }
                        }

                        if (calismadi3) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 4 || Convert.ToInt32(s.Substring(0, 1)) == 5) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 9) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                                    }
                                }
                            }
                        }
                    } else if (oyuncununElindekiKartlardan_i_nci.Contains("Re")) {
                        bool calismadi = true;

                        List<string> geciciListe = new List<string>();

                        foreach (string s in ortadakiKartlar) {
                            if (Convert.ToInt32(s.Substring(0, 1)) == 1 || Convert.ToInt32(s.Substring(0, 1)) == 9) {
                                geciciListe.Add(s);
                            }
                        }
                        for (int a = 0; a < geciciListe.Count; a++) {
                            for (int b = 0; b < geciciListe.Count; b++) {
                                if (a == b) {
                                    return;
                                }
                                if (Convert.ToInt32(geciciListe[a].Substring(0, 1)) + Convert.ToInt32(geciciListe[b].Substring(0, 1)) == 10) {
                                    player.oyuncuKoleksiyonu.Add(geciciListe[a]);
                                    player.oyuncuKoleksiyonu.Add(geciciListe[b]);
                                    ortadakiKartlar.Remove(geciciListe[a]);
                                    ortadakiKartlar.Remove(geciciListe[b]);

                                    player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                    player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                    calismadi = false;
                                }
                            }
                        }

                        bool calismadi2 = true;

                        if (calismadi) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 2 || Convert.ToInt32(s.Substring(0, 1)) == 8) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 10) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi2 = false;
                                    }
                                }
                            }
                        }

                        bool calismadi3 = true;

                        if (calismadi2) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 3 || Convert.ToInt32(s.Substring(0, 1)) == 7) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 10) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi3 = false;
                                    }
                                }
                            }
                        }

                        bool calismadi4 = true;

                        if (calismadi3) {
                            List<string> geciciListe2 = new List<string>();

                            foreach (string s in ortadakiKartlar) {
                                if (Convert.ToInt32(s.Substring(0, 1)) == 4 || Convert.ToInt32(s.Substring(0, 1)) == 6) {
                                    geciciListe2.Add(s);
                                }
                            }
                            for (int a = 0; a < geciciListe2.Count; a++) {
                                for (int b = 0; b < geciciListe2.Count; b++) {
                                    if (a == b) {
                                        return;
                                    }
                                    if (Convert.ToInt32(geciciListe2[a].Substring(0, 1)) + Convert.ToInt32(geciciListe2[b].Substring(0, 1)) == 10) {
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[a]);
                                        player.oyuncuKoleksiyonu.Add(geciciListe2[b]);
                                        ortadakiKartlar.Remove(geciciListe2[a]);
                                        ortadakiKartlar.Remove(geciciListe2[b]);

                                        player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                        player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                        calismadi3 = false;
                                    }
                                }
                            }
                        }

                        if (calismadi4) {
                            List<string> geciciListe2 = new List<string>();
                            foreach (string s in ortadakiKartlar) {
                                if (s.Contains("5"))
                                    geciciListe2.Add(s);
                            }

                            if (geciciListe2.Count == 2) {
                                player.oyuncuKoleksiyonu.AddRange(geciciListe2);

                                player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);

                                for (int a = 0; a < geciciListe2.Count; a++) {
                                    ortadakiKartlar.Remove(geciciListe2[a]);
                                }
                            } else if (geciciListe2.Count >= 2) { // eger ikiden fazla (3) sayıda "5" sayısı içeren kart varsa
                                    Random random = new Random();

                                    string kart1 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                                    player.oyuncuKoleksiyonu.Add(kart1);
                                    ortadakiKartlar.Remove(kart1);
                                    // 3 kart arasından rastgele iki kartı alıp oyuncu koleksiyonuna ekliyoruz
                                    string kart2 = geciciListe2[random.Next(0, geciciListe2.Count - 1)];
                                    player.oyuncuKoleksiyonu.Add(kart2);
                                    ortadakiKartlar.Remove(kart2);
                                

                                player.oyuncuKoleksiyonu.Add(oyuncununElindekiKartlardan_i_nci);
                                player.oyuncuDestesi.Remove(oyuncununElindekiKartlardan_i_nci);
                            }
                        }
                    }
                }
                if (j == 0)
                    break;
            }
            if (i == 0)
                break;
        }

        if (ortadakiKartlar.Count == elinBasindaOrtadakiKartSayisi) { // bu elde oyuncu ortadan hiçbir kart almadıysa
            if(player.oyuncuDestesi.Count != 0) { 
            Random random = new Random();
            string rastgeleKart = player.oyuncuDestesi[random.Next(0, player.oyuncuDestesi.Count - 1)];
            ortadakiKartlar.Add(rastgeleKart); // ortaya rastgele bir kart ekle
            player.oyuncuDestesi.Remove(rastgeleKart);
            }
        }

    }

    public void SonEl(Player player1, Player player2) {
        if (oyunDestesi.Count == 0) {
            if (player1.oyuncuDestesi.Count == 0) {
                player2.oyuncuKoleksiyonu.AddRange(ortadakiKartlar);
                ortadakiKartlar.Clear();
                player2.oyuncuKoleksiyonu.AddRange(player2.oyuncuDestesi);
                player2.oyuncuDestesi.Clear();
            } else if (player2.oyuncuDestesi.Count == 0) {
                player1.oyuncuKoleksiyonu.AddRange(ortadakiKartlar);
                ortadakiKartlar.Clear();
                player1.oyuncuKoleksiyonu.AddRange(player1.oyuncuDestesi);
                player1.oyuncuDestesi.Clear();
            }
        } /*else { // düzenlenmesi gerek (ödevde calismasi icin else i koydum)
            player1.oyuncuKoleksiyonu.AddRange(player1.oyuncuDestesi);
            player2.oyuncuKoleksiyonu.AddRange(player2.oyuncuDestesi);

            player1.oyuncuDestesi.Clear();
            player2.oyuncuDestesi.Clear();

            player2.oyuncuKoleksiyonu.AddRange(ortadakiKartlar); // turun son elinde 2. oyuncu ortadaki kartları alır
            ortadakiKartlar.Clear();
        }*/
    }


    public void PuanHesapla(Player player1, Player player2) {

        // kart sayılarına gore
        if (player1.oyuncuKoleksiyonu.Count > player2.oyuncuKoleksiyonu.Count) {
            player1.oyuncuPuani += 1;
        } else if (player1.oyuncuKoleksiyonu.Count < player2.oyuncuKoleksiyonu.Count) {
            player2.oyuncuPuani += 1;
        }


        // altın içeren kart sayılarına göre
        List<string> altinİcerenKartlar1 = new List<string>();
        foreach (string s in player1.oyuncuKoleksiyonu) {
            if (s.Contains("Altın")) {
                altinİcerenKartlar1.Add(s);
            }
        }

        List<string> altinİcerenKartlar2 = new List<string>();
        foreach (string s in player2.oyuncuKoleksiyonu) {
            if (s.Contains("Altın")) {
                altinİcerenKartlar2.Add(s);
            }
        }

        if (altinİcerenKartlar1.Count > altinİcerenKartlar2.Count) {
            player1.oyuncuPuani += 1;
        } else if (altinİcerenKartlar1.Count < altinİcerenKartlar2.Count) {
            player2.oyuncuPuani += 1;
        }

        // Altın 7'ye sahip olma durumuna göre
        if (player1.oyuncuKoleksiyonu.Contains("Altın" + "7")) {
            player1.oyuncuPuani += 1;
        } else {
            player2.oyuncuPuani += 1;
        }

        // scopa sayıları
        player1.oyuncuPuani += player1.scopaSayisi;
        player2.oyuncuPuani += player2.scopaSayisi;

        // Primiera

        player1.playerPrimieraPuani = PrimieraPuaniHesapla(player1);
        player2.playerPrimieraPuani = PrimieraPuaniHesapla(player2);

        if (player1.playerPrimieraPuani > player2.playerPrimieraPuani) {
            player1.oyuncuPuani += 1;
        } else if (player1.playerPrimieraPuani < player2.playerPrimieraPuani) {
            player2.oyuncuPuani += 1;
        }

        int PrimieraPuaniHesapla(Player player) {

        int altinPuani = 0;
        foreach (string s in player.oyuncuKoleksiyonu) {
            if (s.Contains("Altın")) {
                for (int i = 1; i <= 7; i++) {
                    if (i == Convert.ToInt32(s.Substring(0, 1)))
                        altinPuani = i + 10;
                    if (i == 1) {
                        altinPuani = 16;
                    }
                    if (i == 6) {
                        altinPuani = 18;
                    }
                    if (i == 7) {
                        altinPuani = 21;
                    }
                }
                if (s.Contains("Fante"))
                    altinPuani = 10;
                else if (s.Contains("Cavallo"))
                    altinPuani = 10;
                else if (s.Contains("Re"))
                    altinPuani = 10;
            }
        }

        int kupaPuani = 0;
        foreach (string s in player.oyuncuKoleksiyonu) {
            if (s.Contains("Kupa")) {
                for (int i = 1; i <= 7; i++) {
                    if (i == Convert.ToInt32(s.Substring(0, 1)))
                        kupaPuani = i + 10;
                    if (i == 1) {
                        kupaPuani = 16;
                    }
                    if (i == 6) {
                        kupaPuani = 18;
                    }
                    if (i == 7) {
                        kupaPuani = 21;
                    }
                }
                if (s.Contains("Fante"))
                    kupaPuani = 10;
                else if (s.Contains("Cavallo"))
                    kupaPuani = 10;
                else if (s.Contains("Re"))
                    kupaPuani = 10;
            }
        }

        int kilicPuani = 0;
        foreach (string s in player.oyuncuKoleksiyonu) {
            if (s.Contains("Kupa")) {
                for (int i = 1; i <= 7; i++) {
                    if (i == Convert.ToInt32(s.Substring(0, 1)))
                        kilicPuani = i + 10;
                    if (i == 1) {
                        kilicPuani = 16;
                    }
                    if (i == 6) {
                        kilicPuani = 18;
                    }
                    if (i == 7) {
                        kilicPuani = 21;
                    }
                }
                if (s.Contains("Fante"))
                    kilicPuani = 10;
                else if (s.Contains("Cavallo"))
                    kilicPuani = 10;
                else if (s.Contains("Re"))
                    kilicPuani = 10;
            }
        }

        int sopaPuani = 0;
        foreach (string s in player.oyuncuKoleksiyonu) {
            if (s.Contains("Kupa")) {
                for (int i = 1; i <= 7; i++) {
                    if (i == Convert.ToInt32(s.Substring(0, 1)))
                        sopaPuani = i + 10;
                    if (i == 1) {
                        sopaPuani = 16;
                    }
                    if (i == 6) {
                        sopaPuani = 18;
                    }
                    if (i == 7) {
                        sopaPuani = 21;
                    }
                }
                if (s.Contains("Fante"))
                    sopaPuani = 10;
                else if (s.Contains("Cavallo"))
                    sopaPuani = 10;
                else if (s.Contains("Re"))
                    sopaPuani = 10;
            }
        }
            int toplamPrimieraPuani = altinPuani + kupaPuani + kilicPuani + sopaPuani;
            return toplamPrimieraPuani;
        }
    }

    public void OyuncuKartlarınıGöster(Player player) {
        Console.WriteLine("\n\n--------------------------------------------\n");

        foreach (string s in player.oyuncuKoleksiyonu) {
            Console.WriteLine(s);
        }
    }

    public void OyunuKazananOyuncuyuGoster(Player player1, Player player2) {
        Console.WriteLine("         - OYUN SONUCU -         ");

        if(player1.oyuncuPuani > player2.oyuncuPuani) {
            Console.WriteLine("Oyuncu {0} Kazandı!", player1.oyuncuAdi);
        } else if (player1.oyuncuPuani < player2.oyuncuPuani) {
            Console.WriteLine("Oyuncu {0} Kazandı!", player2.oyuncuAdi);
        } else {
            Console.WriteLine("BERABERE!!!");
        }
    }
}

public class Player {
        public string oyuncuAdi = "Player";
        public int oyuncuPuani;
        public int scopaSayisi;
        public int playerPrimieraPuani;

        public List<string> oyuncuDestesi = new List<string>(); // elindeki deste
        public List<string> oyuncuKoleksiyonu = new List<string>(); // aldığı kartlar
}