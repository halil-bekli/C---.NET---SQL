using System.Collections;

namespace Ödev4 {
    public partial class Form1 : Form {

        //public event EventHandler FaktoriyelSecildiginde;

        //public Form1 Instance { get; private set; }

        ComboBox islemListesi = new ComboBox();
        Label label1 = new Label();
        Label label2 = new Label();
        TextBox textBox1 = new TextBox();
        TextBox textBox2 = new TextBox();
        Button button = new Button();
        Button ozetButonu = new Button();
        ComboBox trigonometrikFonksiyonListesi = new ComboBox();

        static List<int> faktoriyeldekiDegerler = new List<int>();
        static List<int> ustelfonkdakiDegerler = new List<int>();
        static List<int> asalMidakiDegerler = new List<int>();
        static List<double> trigonometrikİslemlerdekiDegerler = new List<double>();

        static double sinDegeri;
        static double kosDegeri;
        static double tanDegeri;
        static double arcsinDegeri;
        static double arccosDegeri;
        static double arctanDegeri;

        static int sayi1;
        static int sayi2;

        static int faktoriyel;
        static int sayininUsteli;
        static string sayininAsalligi;

        ArrayList inputVeOutputlar = new ArrayList();

        static double aci;
        static double aciRadyan;

        bool ikinciComboBoxuOlustur = true;

        public Form1() {
            InitializeComponent();

            HideProperties();

            Etiket1iOlustur();
            Etiket2iOlustur();

            ButtonOlustur();
            OzetButonuOlustur();

            TextBox1iOlustur();
            TextBox2iOlustur();

            TextBox1yiSakla();
            TextBox2yiSakla();

            Etiket1iSakla();
            Etiket2iSakla();

            TrigonometrikFonksiyonListesiniSakla();
        }

        private void Form1_Load(object sender, EventArgs e) {
            MessageBox.Show("Hangi işlemi yapmak istiyorsun?");

            islemListesi.Location = new System.Drawing.Point(270, 185);
            islemListesi.Size = new System.Drawing.Size(200, 100);
            islemListesi.BackColor = Color.DarkSeaGreen;
            islemListesi.Text = "İşlem Listesi";

            islemListesi.Items.Add("Faktöriyel Hesaplama");
            islemListesi.Items.Add("Üstel Değer Hesaplama");
            islemListesi.Items.Add("Asallık Kontrolü");
            islemListesi.Items.Add("Trigonometrik İşlemler");

            Controls.Add(islemListesi);

            BackColor = Color.AntiqueWhite;

            islemListesi.SelectedIndexChanged += İslemListesi_SelectedIndexChanged;
            trigonometrikFonksiyonListesi.SelectedIndexChanged += TrigonometrikFonksiyonListesi_SelectedIndexChanged;
            button.Click += Button_Click;
            ozetButonu.Click += OzetButonu_Click;
        }

        private void OzetButonu_Click(object? sender, EventArgs e) {

            string degerler = null;
            
            foreach (var item in inputVeOutputlar) {
                degerler += item.ToString() + " ";
            }

            MessageBox.Show(degerler);
        }

        private void TrigonometrikFonksiyonListesi_SelectedIndexChanged(object? sender, EventArgs e) {
            try {
                if (islemListesi.SelectedIndex == 3) { // islem listesinde 3 uncu sıra seciliyse
                    if(trigonometrikFonksiyonListesi.SelectedIndex == 0) {

                    }    
                }
            } catch {
                DialogResult dialogResult = MessageBox.Show("Lütfen işlemi doğru seç. (E.t: Trigonometrik İşlemler)");
            }
        }

        private void İslemListesi_SelectedIndexChanged(object? sender, EventArgs e) {
            if (islemListesi.SelectedItem == islemListesi.Items[0]) {
                FaktoriyelHesaplayıcıDuzeni();
            } else if (islemListesi.SelectedItem == islemListesi.Items[1]) {
                UstelDegerHesaplayıcıDuzeni();
            } else if (islemListesi.SelectedItem == islemListesi.Items[2]) {
                AsalMiDuzeni();
            } else if (islemListesi.SelectedItem == islemListesi.Items[3]) {
                TrigonometrikİslemlerDuzeni();
            }
        }

        private void Button_Click(object? sender, EventArgs e) {
            if (islemListesi.SelectedItem == islemListesi.Items[0]) {
                faktoriyeldekiDegerler.AddRange(FaktoriyelHesaplayıcı());

                inputVeOutputlar.Add("Faktoriyeli istenen sayı ve faktöriyeli: ");
                inputVeOutputlar.AddRange(faktoriyeldekiDegerler);
                inputVeOutputlar.Add("\n");
            } else if (islemListesi.SelectedItem == islemListesi.Items[1]) {
                ustelfonkdakiDegerler.AddRange(UstelDegerHesaplayıcı());

                inputVeOutputlar.Add("Üstel değeri istenen sayı, üstü ve işlemin sonucu: ");
                inputVeOutputlar.AddRange(ustelfonkdakiDegerler);
                inputVeOutputlar.Add("\n");
            } else if (islemListesi.SelectedItem == islemListesi.Items[2]) {
                AsalMi();

                inputVeOutputlar.Add("Asallığı istenen sayı ve sonucu: ");
                inputVeOutputlar.AddRange(asalMidakiDegerler);
                if(AsalMi() == true) {
                    inputVeOutputlar.Add(" - ASAL");
                } else {
                    inputVeOutputlar.Add(" - ASAL DEĞİL");
                }
                inputVeOutputlar.Add("\n");
            } else if (islemListesi.SelectedItem == islemListesi.Items[3]) { // islem listesinde Trigonometrikİslemler seciliyse
                Trigonometrikİslemler();

                if (trigonometrikFonksiyonListesi.SelectedIndex == 0) {
                    SinusFonksiyonu();
                } else if(trigonometrikFonksiyonListesi.SelectedIndex == 1) {
                    KosinusFonksiyonu();
                } else if (trigonometrikFonksiyonListesi.SelectedIndex == 3) {
                    TanjantFonksiyonu();
                } else if (trigonometrikFonksiyonListesi.SelectedIndex == 4) {
                    ArcsinusFonksiyonu();
                } else if (trigonometrikFonksiyonListesi.SelectedIndex == 5) {
                    ArccosinusFonksiyonu();
                } else if (trigonometrikFonksiyonListesi.SelectedIndex == 6) {
                    ArctanjantFonksiyonu();
                }
            }
        }

        private List<int> FaktoriyelHesaplayıcı() {
            sayi1 = Convert.ToInt32(textBox1.Text);

            faktoriyel = 1;

            for (int i = 1; i <= sayi1; i++) {
                faktoriyel *= i;
            }

            List<int> faktoriyeldekiDegerler = new List<int>() { sayi1, faktoriyel };

            return faktoriyeldekiDegerler;
        }

        private void FaktoriyelHesaplayıcıDuzeni() {
            Etiket1iGoster();
            Etiket2iSakla();
            TextBox1yiGoster();
            TextBox2yiSakla();
            TrigonometrikFonksiyonListesiniSakla();

            label1.Location = new Point(70, 265);
            label1.Text = "Faktoriyelini hesaplamak istediğin sayıyı gir: ";
            label1.BackColor = Color.Green;

            textBox1.Location = new Point(350, 265);
            label1.Size = new Size(250, 20);
        }

        private List<int> UstelDegerHesaplayıcı() {
            sayi1 = Convert.ToInt32(textBox1.Text);
            sayi2 = Convert.ToInt32(textBox2.Text);

            sayininUsteli = 1;

            for (int i = 1; i <= Convert.ToInt32(textBox2.Text); i++) {
                sayininUsteli *= Convert.ToInt32(textBox1.Text);
            }

            List<int> ustelfonkdakiDegerler = new List<int>() { sayi1, sayi2, sayininUsteli };

            return ustelfonkdakiDegerler;
        }

        private void UstelDegerHesaplayıcıDuzeni() {
            Etiket1iGoster();
            Etiket2iGoster();
            TextBox1yiGoster();
            TextBox2yiGoster();
            TrigonometrikFonksiyonListesiniSakla();

            label1.Text = "Ustel olarak hesaplamak istediğin sayıyı gir: ";
            label2.Text = "Sayının ustunu gir: ";

            label1.Location = new Point(45, 265);
            label2.Location = new Point(420, 265);

            textBox1.Location = new Point(300, 265);
            textBox2.Location = new Point(625, 265);
        }

        private bool AsalMi() {
            sayi1 = Convert.ToInt32(textBox1.Text);

            if (sayi1 == 1) {
                return false;
            } else if (sayi1 == 2) {
                asalMidakiDegerler.Add(sayi1);
                return true;
            } else if (sayi1 == 3) {
                asalMidakiDegerler.Add(sayi1);
                return true;
            } else if (sayi1 == 4) {
                return false;
            } else if (sayi1 == 5) {
                return false;
            } else if (sayi1 == 6) {
                return false;
            } else if (sayi1 % 2 == 1 && !(sayi1 % 3 == 0 || sayi1 % 5 == 0 || sayi1 % 6 == 0 || sayi1 % 7 == 0)) {
                asalMidakiDegerler.Add(sayi1);
                return true;
            } else {
                return false;
            }
        }

        private void AsalMiDuzeni() {
            Etiket1iGoster();
            Etiket2iSakla();
            TextBox1yiGoster();
            TextBox2yiSakla();
            TrigonometrikFonksiyonListesiniSakla();

            label1.Location = new Point(70, 265);
            label1.Text = "Asallığını kontrol etmek istediğin sayıyı gir: ";

            textBox1.Location = new Point(350, 265);
        }

        private void Trigonometrikİslemler() {
            aci = Convert.ToDouble(textBox1.Text);
            aciRadyan = aci * Math.PI / 180;
            
            trigonometrikİslemlerdekiDegerler.Add(aci);
        }

        private void TrigonometrikİslemlerDuzeni() {
            if (ikinciComboBoxuOlustur) {
                İkinciComboBoxOlustur();
                ikinciComboBoxuOlustur = false;
            }

            Etiket1iGoster();
            Etiket2iSakla();
            TextBox1yiGoster();
            TextBox2yiSakla();
            TrigonometrikFonksiyonListesiniGoster();

            label1.Location = new Point(70, 265);
            label1.Text = "Değerini hesaplamak istediğin açıyı gir: ";

            textBox1.Location = new Point(350, 265);
        }

        private void SinusFonksiyonu() {
            sinDegeri = Math.Sin(aciRadyan);

            inputVeOutputlar.Add("Verilen açı ve sinüsü: " + aci + "   " + sinDegeri.ToString("N3") + "\n");
        }

        private void KosinusFonksiyonu() {
            kosDegeri = Math.Cos(aciRadyan);

            inputVeOutputlar.Add("Verilen açı ve kosinüsü: " + aci + "   " + kosDegeri.ToString("N3") + "\n");
        }

        private void TanjantFonksiyonu() {
            tanDegeri = Math.Tan(aciRadyan);

            inputVeOutputlar.Add("Verilen açı ve tanjantı: " + aci+ "   " + tanDegeri.ToString("N3") + "\n");
        }

        private void ArcsinusFonksiyonu() {
            arcsinDegeri = Math.Tan(aciRadyan);

            inputVeOutputlar.Add("Verilen açı ve arcsinüsü: " + aci + "   " + arcsinDegeri.ToString("N3") + "\n");

        }

        private void ArccosinusFonksiyonu() {
           arccosDegeri = Math.Acos(aciRadyan);

           inputVeOutputlar.Add("Verilen açı ve arccosinüsü: " + aci + "   " + arccosDegeri.ToString("N3") + "\n");
        }

        private void ArctanjantFonksiyonu() {
            arctanDegeri = Math.Atan(aciRadyan);

            inputVeOutputlar.Add("Verilen açı ve arctanjantı: " + aci + "   " + arctanDegeri.ToString("N3") + "\n");
        }

        private void HideProperties() {
            foreach (Control control in this.Controls) {
                control.Visible = false;
            }
        }

        private void Etiket1iGoster() {
            label1.Visible = true;
        }
        private void Etiket2iGoster() {
            label2.Visible = true;
        }

        private void Etiket1iSakla() {
            label1.Visible = false;
        }
        private void Etiket2iSakla() {
            label2.Visible = false;
        }

        private void TextBox1yiGoster() {
            textBox1.Visible = true;
        }
        private void TextBox2yiGoster() {
            textBox2.Visible = true;
        }
        private void TextBox1yiSakla() {
            textBox1.Visible = false;
        }
        private void TextBox2yiSakla() {
            textBox2.Visible = false;
        }

        private void TrigonometrikFonksiyonListesiniGoster() {
            trigonometrikFonksiyonListesi.Visible = true;
        }
        private void TrigonometrikFonksiyonListesiniSakla() {
            trigonometrikFonksiyonListesi.Visible = false;
        }

        private void Etiket1iOlustur() {
            label1.Location = new Point(70, 265);
            label1.Size = new Size(250, 20);
            label1.BackColor = Color.Azure;

            Controls.Add(label1);
        }
        private void Etiket2iOlustur() {

            label2.Location = new Point(455, 265);
            label2.Size = new Size(200, 20);
            label2.BackColor = Color.Azure;

            Controls.Add(label2);
        }

        private void TextBox1iOlustur() {

            textBox1.Location = new Point(200, 265);
            textBox1.Size = new Size(95, 25);
            textBox1.BackColor = Color.PaleTurquoise;

            Controls.Add(textBox1);
        }

        private void TextBox2iOlustur() {
            textBox2.Location = new Point(500, 265);
            textBox2.Size = new Size(95, 25);
            textBox2.BackColor = Color.PaleTurquoise;

            Controls.Add(textBox2);
        }

        private void ButtonOlustur() {

            button.Location = new Point(310, 330);
            button.Size = new Size(120, 35);
            button.BackColor = Color.Gold;

            button.TextAlign = ContentAlignment.MiddleCenter;
            button.Text = "HESAPLA";
            button.Font = new Font("Microsoft Sans Serif", 10);

            Controls.Add(button);
        }

        private void OzetButonuOlustur() {
            ozetButonu.Location = new Point(330, 380);
            ozetButonu.Size = new Size(80, 35);
            ozetButonu.BackColor = Color.Azure;

            ozetButonu.TextAlign = ContentAlignment.MiddleCenter;
            ozetButonu.Text = "ÖZET";
            ozetButonu.Font = new Font("Segoe UI", 10);

            Controls.Add(ozetButonu);
        }

        private void İkinciComboBoxOlustur() {

            trigonometrikFonksiyonListesi.Location = new Point(300, 220);
            trigonometrikFonksiyonListesi.BackColor = Color.DarkSeaGreen;

            trigonometrikFonksiyonListesi.Items.Add("Sinüs");
            trigonometrikFonksiyonListesi.Items.Add("Kosinüs");
            trigonometrikFonksiyonListesi.Items.Add("Tanjant");
            trigonometrikFonksiyonListesi.Items.Add("Arcsinüs");
            trigonometrikFonksiyonListesi.Items.Add("Arccosinüs");
            trigonometrikFonksiyonListesi.Items.Add("Arctanjant");

            Controls.Add(trigonometrikFonksiyonListesi);
        }

    }
}