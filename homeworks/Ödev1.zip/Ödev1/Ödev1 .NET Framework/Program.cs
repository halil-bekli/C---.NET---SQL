﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ödev1.NET_Framework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int simdiki_yil = 2024;
            int simdiki_ay = 2;     // bugünün tarihini statik olarak giriyorum
            int simdiki_gun = 28;

            string isim, soyisim, numara, cinsiyet;
            int dogum_yili, dogum_ayi, dogum_gunu;

            // kullanıcıdan gerekli bilgileri alıyorum
            Console.WriteLine("Lutfen adini gir: ");
            isim = Console.ReadLine();

            Console.WriteLine("Lutfen soyadini gir: ");
            soyisim = Console.ReadLine();

            Console.WriteLine("Lutfen numaranı gir: ");
            numara = Console.ReadLine();

            Console.WriteLine("Lutfen cinsiyetini gir (Erkek / Kadın): ");
            cinsiyet = Console.ReadLine();

            Console.WriteLine("Lutfen doğum tarihinin yılını gir: ");
            dogum_yili = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Lutfen doğum tarihinin ayını gir: ");
            dogum_ayi = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Lutfen doğum tarihinin gununu gir: ");
            dogum_gunu = Convert.ToInt32(Console.ReadLine());

            int verilen_gun;

            // 18 yas kontrolü için bool olusturuyorum
            bool onsekizyasinda = (dogum_gunu >= simdiki_gun && dogum_ayi >= simdiki_ay && simdiki_yil - 18 >= dogum_yili) || (simdiki_yil - 18 > dogum_yili) || dogum_ayi > simdiki_ay && simdiki_yil - 18 >= dogum_yili;

            Console.WriteLine("Kaç gün sonra işin var? :");
            verilen_gun = Convert.ToInt32(Console.ReadLine()); // Kaç gün sonra isinin oldugunu soruyorum
            WorkHandler();

            void WorkHandler() // İsin, kullanicinin kendi takvimine gore ay ve gününü hesaplamak ve yazdırmak için oluşturduğum fonksiyon
            { // iki cinsiyet kontrolü ve onların altında da ikiser yas kontrolu ile olusturdum
                int kalan_gun;
                int hafta_sayisi;
                int kalan_hafta_sayisi;
                int ay_sayisi;
                int aydakiGunSayisi;

                if (cinsiyet == "Kadın") // cinsiyet kontrolü
                {
                    hafta_sayisi = verilen_gun / 5; // Kadinlar icin hafta 5 gun oldugundan verilen gunun ozel takvimde kac haftaya denk geldigini buluyorum
                    kalan_gun = verilen_gun % 5; // Hafta_sayisi asagıda ay sayisi için kullanilacak

                    if (onsekizyasinda) // yas kontrolü
                    {
                        ay_sayisi = hafta_sayisi / 5; // 18 yasindan buyuk kadinlar icin bir ay 5 hafta oldugundan, verilen hafta sayısının ozel takvimde kac aya denk geldigini buluyorum
                        kalan_hafta_sayisi = hafta_sayisi % 5; // İsin gununu hesaplamak için kulanılacak

                        aydakiGunSayisi = 25;
                        int yas = (simdiki_gun - dogum_gunu + (simdiki_ay - dogum_ayi) * aydakiGunSayisi + (simdiki_yil - dogum_yili) * aydakiGunSayisi * 12) / (aydakiGunSayisi * 12);
                        // Kullanıcının yasını ozel takvime gore hesaplıyorum ancak eger normal takvime gore hesaplamam gerekirse 
                        // aydakiGunSayisi na "30" atayarak bunu yapabilirim.

                        int isingunu = kalan_hafta_sayisi * 5 + kalan_gun; // İsin, ayin kacıncı gununde olacagını hesaplıyorum

                        if (isingunu == 0)
                        { // eger ay sonuna denk geliyorsa isin gununu ayın son gunu olarak ayarlıyorum
                            ay_sayisi--;
                            isingunu = 25;
                        }

                        Console.WriteLine("Sayın {0} isimli {1} soyisimli hanım {2} yaşındasınız. {3}. ayın {4}. gününde " +
                            "işiniz bulunmaktadır.", isim, soyisim, yas, ay_sayisi + 1, isingunu);
                    }
                    else // 18 yasında olmayan kadınlar için
                    {
                        ay_sayisi = hafta_sayisi / 6;
                        kalan_hafta_sayisi = hafta_sayisi % 6;

                        aydakiGunSayisi = 30;
                        int yas = (simdiki_gun - dogum_gunu + (simdiki_ay - dogum_ayi) * aydakiGunSayisi + (simdiki_yil - dogum_yili) * aydakiGunSayisi * 12) / (aydakiGunSayisi * 12);

                        int isingunu = kalan_hafta_sayisi * 5 + kalan_gun;

                        if (isingunu == 0)
                        {
                            ay_sayisi--;
                            isingunu = 30;
                        }

                        Console.WriteLine("Sayın {0} isimli {1} soyisimli hanım {2} yaşındasınız. {3}. ayın {4}. gününde " +
                            "işiniz bulunmaktadır.", isim, soyisim, yas, ay_sayisi + 1, isingunu);
                    }
                }
                else if (cinsiyet == "Erkek")
                {
                    hafta_sayisi = verilen_gun / 8;
                    kalan_gun = verilen_gun % 8;

                    if (onsekizyasinda)
                    {
                        ay_sayisi = hafta_sayisi / 5;
                        kalan_hafta_sayisi = hafta_sayisi % 5;

                        aydakiGunSayisi = 40;
                        int yas = (simdiki_gun - dogum_gunu + (simdiki_ay - dogum_ayi) * aydakiGunSayisi + (simdiki_yil - dogum_yili) * aydakiGunSayisi * 12) / (aydakiGunSayisi * 12);

                        int isingunu = kalan_hafta_sayisi * 8 + kalan_gun;

                        if (isingunu == 0)
                        {
                            ay_sayisi--;
                            isingunu = 40;
                        }

                        Console.WriteLine("Sayın {0} isimli {1} soyisimli bey {2} yaşındasınız. {3}. ayın {4}. gününde " +
                            "işiniz bulunmaktadır.", isim, soyisim, yas, ay_sayisi + 1, isingunu);
                    }
                    else
                    {
                        ay_sayisi = hafta_sayisi / 6;
                        kalan_hafta_sayisi = hafta_sayisi % 6;

                        aydakiGunSayisi = 48;
                        int yas = (simdiki_gun - dogum_gunu + (simdiki_ay - dogum_ayi) * aydakiGunSayisi + (simdiki_yil - dogum_yili) * aydakiGunSayisi * 12) / (aydakiGunSayisi * 12);

                        int isingunu = kalan_hafta_sayisi * 8 + kalan_gun;

                        if (isingunu == 0)
                        {
                            ay_sayisi--;
                            isingunu = 48;
                        }

                        Console.WriteLine("Sayın {0} isimli {1} soyisimli bey {2} yaşındasınız. {3}. ayın {4}. gününde " +
                            "işiniz bulunmaktadır.", isim, soyisim, yas, ay_sayisi + 1, isingunu);
                    }
                }
            }
        }
    }
}